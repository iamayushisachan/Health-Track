# Health Track

## Project Setup

1. Install dependencies
```
npm install
```

2. Create `.env` file from `.env.example`

3. Start the server
```
node backend/server.js
```

## MySQL Setup
- Import `database/healthtrack_schema.sql` into MySQL

## Features
- Track medicines, water intake, sleep hours
- Visual dashboard with Chart.js