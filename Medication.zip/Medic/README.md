# TakeYaPill - The Medication Reminder
A Web App that periodically reminds you about your Medicines, Vitamins and Water

Funtions : 
- Add Medines and other suppliments
- Add Description to remember what exactly the pill does
- Add the expriy date which will automatically erase the Pill after it expires
- Notifies you at proper time to take the pill
- CRUD operations
 
 Url : https://sayakongit.github.io/HTF21-Team-44/
 
